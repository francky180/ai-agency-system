import React from "react";
import { Composition } from "remotion";
import { ClientFlowVideo } from "./Video";
import { FPS, DURATION_FRAMES } from "./theme";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="ClientFlowVideo"
        component={ClientFlowVideo}
        durationInFrames={DURATION_FRAMES}
        fps={FPS}
        width={1920}
        height={1080}
      />
    </>
  );
};
